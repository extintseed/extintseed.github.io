const http = require("http");
const fs = require("fs");
const path = require("path");

// Escucha en la red local para poder abrir la presentación desde un celular
// conectado al mismo router o punto de acceso.
const HOST = process.env.HOST || "0.0.0.0";
const PORT = 8080;
const ROOT = __dirname;

const MIME_TYPES = {
    ".css": "text/css; charset=utf-8",
    ".gif": "image/gif",
    ".html": "text/html; charset=utf-8",
    ".ico": "image/x-icon",
    ".jpeg": "image/jpeg",
    ".jpg": "image/jpeg",
    ".js": "text/javascript; charset=utf-8",
    ".png": "image/png",
    ".svg": "image/svg+xml",
    ".txt": "text/plain; charset=utf-8",
    ".webp": "image/webp"
};

function sendText(response, statusCode, message) {
    response.writeHead(statusCode, { "Content-Type": "text/plain; charset=utf-8" });
    response.end(message);
}

const server = http.createServer((request, response) => {
    let pathname;

    try {
        pathname = decodeURIComponent(new URL(request.url, `http://${HOST}:${PORT}`).pathname);
    } catch {
        sendText(response, 400, "Solicitud no válida.");
        return;
    }

    const requestedPath = pathname === "/" ? "/index.html" : pathname;
    const filePath = path.resolve(ROOT, `.${requestedPath}`);
    const isInsideProject = filePath === ROOT || filePath.startsWith(`${ROOT}${path.sep}`);

    if (!isInsideProject) {
        sendText(response, 403, "Acceso denegado.");
        return;
    }

    fs.stat(filePath, (statError, stats) => {
        if (statError || !stats.isFile()) {
            sendText(response, 404, "Archivo no encontrado.");
            return;
        }

        response.writeHead(200, {
            "Cache-Control": "no-store",
            "Content-Type": MIME_TYPES[path.extname(filePath).toLowerCase()] || "application/octet-stream"
        });

        if (request.method === "HEAD") {
            response.end();
            return;
        }

        fs.createReadStream(filePath).pipe(response);
    });
});

server.listen(PORT, HOST, () => {
    console.log(`EXTINT S.E.E.D disponible en http://localhost:${PORT}`);
});
